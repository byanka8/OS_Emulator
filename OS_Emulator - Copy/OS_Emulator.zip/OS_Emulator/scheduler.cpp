#include <vector>
#include "utils.h"
#include <iostream>
#include <algorithm> 


Scheduler::Scheduler(int cores)
	: numCores(cores), processQueues(cores) {
}

// Add process to the scheduler
void Scheduler::addProcess(const ProcessScreen& process, int core) {
	
	if (core >= 0 && core < numCores) {
		processQueues[core].push_back(process);
	}
	else {
		std::cerr << "Invalid core specified for process addition.\n";
	}

}

// Sort the process queues based on remaining instructions
void Scheduler::sortProcessQueues() {
    for (auto& queue : processQueues) {
        std::sort(queue.begin(), queue.end(), [](const ProcessScreen& a, const ProcessScreen& b) {
            return a.getRemainingInstructions() < b.getRemainingInstructions();
        });
    }
}

void Scheduler::runScheduler() {
	int i = 0;
	while (!processQueues[0].empty()) {
		for (int core = 0; core < numCores; ++core) {
			if (!processQueues[core].empty()) {
				ProcessScreen currentProcess = processQueues[core].back();
				processQueues[core].pop_back();

				while (!currentProcess.hasFinished()) {
					currentProcess.executeInstruction();
				}

				std::cout << "Process" << currentProcess.getRemainingInstructions() << " completed on core " << core + i << ".\n";

				i++;
			}
		}
	}
}
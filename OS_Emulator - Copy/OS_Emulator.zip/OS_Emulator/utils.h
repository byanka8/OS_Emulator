#pragma once
#include <map>
#include <string>
#include <vector>
#include <iostream>

//Struct for the Process to show up will probably add more later on to show completion of instructions
struct ProcessScreen {
    std::string name;
    int id = 0;
    int totalInstructions = 0;
    int currentInstructions = 1;
    std::string timestamp;

    int getRemainingInstructions() const {
        return totalInstructions - currentInstructions;
    }

    bool hasFinished() const {
        return getRemainingInstructions() == 0;
    }

    void executeInstruction() {
        int remainingInstructions = totalInstructions - currentInstructions;
        if (remainingInstructions > 0) {
            std::cout << "Executing instruction for Process " << id << ": " << name << "\n";
            currentInstructions++;
        }
        else {
            std::cout << "Process " << id << ": " << name << " has already finished.\n";
        }
    }
};

class Scheduler {
private:
    int numCores;
    std::vector<std::vector<ProcessScreen>> processQueues;

public:
    Scheduler(int cores);  // Constructor

    // Add process to a core's queue
    void addProcess(const ProcessScreen& process, int core = 0);

    // Sort each core's queue by remaining instructions
    void sortProcessQueues();

    void runScheduler();
};

// Other utils
std::string getCurrentTimestamp();
void readConfig(const std::string& filename,
    int& numCpu,
    std::string& scheduler,
    int& quantumCycles,
    int& batchProcessFreq,
    int& minIns,
    int& maxIns,
    int& delayPerExec);

// Console start page functions
void printMenuTopBorder();

void rowOne();
void rowTwo();
void rowThree();
void rowFour();
void rowFive();
void rowSix();
void rowSeven();
void rowEight();
void rowNine();

void printMenuMiddleBorder();
void printMenuBottomBorder();
void printCenteredGreeting(const char* message);

void startUp();		//Full opening page :D

void clearScreen();
void handleScreenCommand(const char* input, std::map<std::string, ProcessScreen>& processScreens);

// Process functions

void drawProcessScreen(const ProcessScreen& ps);
void processScreenLoop(const std::string& name);
ProcessScreen createProcess(std::string name, int id, int totalInstructions);